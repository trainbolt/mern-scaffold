import palette from "../palette";

export default {};
