export default {
  root: {
    boxShadow: "none"
  }
};
